interface Exercise {
  image: string;
  name: string;
}

interface ExerciseListProps {
  exercises: Exercise[];
}

export function ExerciseList({ exercises }: ExerciseListProps) {
  return (
    <div className="bg-[#ff8654] rounded-[10px] overflow-hidden shadow-lg">
      {exercises.map((exercise, index) => (
        <div key={index}>
          <div className="flex items-center p-4 md:p-5">
            <div className="w-14 h-14 md:w-16 md:h-16 rounded-lg overflow-hidden flex-shrink-0 bg-gray-200">
              <img
                src={exercise.image}
                alt={exercise.name}
                className="w-full h-full object-cover"
              />
            </div>
            <p
              className="ml-4 md:ml-6 text-black"
              style={{ fontSize: "15px", fontFamily: "Poppins, sans-serif" }}
            >
              {exercise.name}
            </p>
          </div>
          {index < exercises.length - 1 && (
            <div className="h-[2px] bg-white" />
          )}
        </div>
      ))}
    </div>
  );
}
