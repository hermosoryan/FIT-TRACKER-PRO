import { useState } from "react";

interface TimerProps {
  svgPaths: {
    p36059680: string;
    p1bbeb700: string;
  };
}

export function Timer({ svgPaths }: TimerProps) {
  const [isRunning, setIsRunning] = useState(false);

  return (
    <div className="flex items-center justify-center">
      <div className="relative w-full max-w-[350px] aspect-square">
        {/* Circle with gradient stroke */}
        <svg
          className="absolute inset-0 w-full h-full"
          viewBox="0 0 407 402"
          fill="none"
          preserveAspectRatio="xMidYMid meet"
        >
          <path
            d={svgPaths.p1bbeb700}
            stroke="url(#paint0_linear_5_149)"
            strokeWidth="5"
          />
          <defs>
            <linearGradient
              gradientUnits="userSpaceOnUse"
              id="paint0_linear_5_149"
              x1="203.5"
              x2="203.5"
              y1="0"
              y2="402"
            >
              <stop offset="0.235577" stopColor="#FF4B00" />
              <stop offset="0.610577" stopColor="#ED8B62" />
            </linearGradient>
          </defs>
        </svg>

        {/* Timer Content */}
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          {/* Timer Display */}
          <div
            className="text-black text-5xl md:text-6xl mb-4 md:mb-8"
            style={{ fontFamily: "Poppins, sans-serif" }}
          >
            00:00
          </div>

          {/* Play Button */}
          <button
            onClick={() => setIsRunning(!isRunning)}
            className="w-16 h-16 md:w-20 md:h-20 flex items-center justify-center hover:scale-110 transition-transform"
            aria-label={isRunning ? "Pause" : "Play"}
          >
            <svg
              width="75"
              height="84"
              viewBox="0 0 81 84"
              fill="none"
              className="w-full h-full"
            >
              <g>
                <path d={svgPaths.p36059680} fill="black" />
              </g>
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
}
