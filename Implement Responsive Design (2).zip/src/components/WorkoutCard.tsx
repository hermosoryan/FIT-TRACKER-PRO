import { Clock, Flame, Dumbbell } from "lucide-react";

interface WorkoutCardProps {
  image: string;
}

export function WorkoutCard({ image }: WorkoutCardProps) {
  return (
    <div className="bg-white rounded-[18px] overflow-hidden shadow-lg">
      {/* Workout Image */}
      <div className="relative h-48 md:h-56 overflow-hidden">
        <div className="absolute top-3 left-3 bg-[#ff4b00] text-white px-3 py-1 rounded-[5px] text-xs md:text-sm z-10">
          Intermediate
        </div>
        <img
          src={image}
          alt="Core Crusher"
          className="w-full h-full object-cover"
        />
      </div>

      {/* Workout Info */}
      <div className="p-4 md:p-6">
        <h3 className="text-xl md:text-2xl mb-2">Core Crusher</h3>
        <p className="text-gray-600 text-sm mb-4" style={{ fontSize: "15px", fontFamily: "Poppins, sans-serif" }}>
          Tighten the abs and build core muscle.
        </p>

        {/* Workout Stats */}
        <div className="space-y-2 mb-6">
          <div className="flex items-center text-gray-700">
            <Clock size={16} className="mr-2" />
            <span style={{ fontSize: "15px", fontFamily: "Poppins, sans-serif" }}>20 min</span>
          </div>
          <div className="flex items-center text-gray-700">
            <Flame size={16} className="mr-2" />
            <span style={{ fontSize: "15px", fontFamily: "Poppins, sans-serif" }}>180 cal</span>
          </div>
          <div className="flex items-center text-gray-700">
            <Dumbbell size={16} className="mr-2" />
            <span style={{ fontSize: "15px", fontFamily: "Poppins, sans-serif" }}>Bodyweight</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="space-y-3">
          <button
            className="w-full bg-gradient-to-r from-[#ff4b00] to-[#ff7c45] text-white py-3 rounded-[5px] hover:from-[#e64400] hover:to-[#e66d3a] transition-all"
            style={{ fontSize: "15px", fontFamily: "Poppins, sans-serif" }}
          >
            Start Workout
          </button>
          <button
            className="w-full bg-gradient-to-r from-[#ff4b00] to-[#ff7c45] text-white py-3 rounded-[5px] hover:from-[#e64400] hover:to-[#e66d3a] transition-all"
            style={{ fontSize: "15px", fontFamily: "Poppins, sans-serif" }}
          >
            End Workout
          </button>
        </div>
      </div>
    </div>
  );
}
