import { Instagram, Youtube, Twitter, Linkedin } from "lucide-react";

export function Footer() {
  const productLinks = [
    "Features",
    "Workouts",
    "Programs",
    "Progress Tracking",
  ];

  const companyLinks = [
    "About Us",
    "Blog",
    "Careers",
    "Contact",
  ];

  const supportLinks = [
    "Help Center",
    "Privacy Policy",
    "Term of Service",
  ];

  return (
    <footer className="text-white mt-12 md:mt-20 py-8 md:py-12" style={{ backgroundColor: "#0080FFEB" }}>
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
          {/* Brand Section */}
          <div className="lg:col-span-1">
            <h3
              className="mb-3"
              style={{ fontSize: "20px", fontFamily: "Poppins, sans-serif" }}
            >
              Fit Tracker Pro
            </h3>
            <p
              className="text-white/90 mb-4 max-w-xs"
              style={{ fontSize: "13px", fontFamily: "Poppins, sans-serif", lineHeight: "1.6" }}
            >
              Transform your fitness journey with intelligent workout tracking, personalized programs, and comprehensive progress analytics.
            </p>
            
            {/* Social Media Icons */}
            <div className="flex items-center space-x-3">
              <a
                href="#"
                className="w-10 h-10 rounded-[8px] bg-white hover:bg-white/90 flex items-center justify-center transition-colors"
                aria-label="Instagram"
              >
                <Instagram size={18} className="text-[#0080FFEB]" />
              </a>
              <a
                href="#"
                className="w-10 h-10 rounded-[8px] bg-white hover:bg-white/90 flex items-center justify-center transition-colors"
                aria-label="Youtube"
              >
                <Youtube size={18} className="text-[#0080FFEB]" />
              </a>
              <a
                href="#"
                className="w-10 h-10 rounded-[8px] bg-white hover:bg-white/90 flex items-center justify-center transition-colors"
                aria-label="Twitter"
              >
                <Twitter size={18} className="text-[#0080FFEB]" />
              </a>
              <a
                href="#"
                className="w-10 h-10 rounded-[8px] bg-white hover:bg-white/90 flex items-center justify-center transition-colors"
                aria-label="LinkedIn"
              >
                <Linkedin size={18} className="text-[#0080FFEB]" />
              </a>
            </div>
          </div>

          {/* Product Section */}
          <div>
            <h4
              className="mb-4"
              style={{ fontSize: "16px", fontFamily: "Poppins, sans-serif" }}
            >
              Product
            </h4>
            <ul className="space-y-2">
              {productLinks.map((link) => (
                <li key={link}>
                  <a
                    href="#"
                    className="text-white/90 hover:text-white transition-colors"
                    style={{ fontSize: "14px", fontFamily: "Poppins, sans-serif" }}
                  >
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Company Section */}
          <div>
            <h4
              className="mb-4"
              style={{ fontSize: "16px", fontFamily: "Poppins, sans-serif" }}
            >
              Company
            </h4>
            <ul className="space-y-2">
              {companyLinks.map((link) => (
                <li key={link}>
                  <a
                    href="#"
                    className="text-white/90 hover:text-white transition-colors"
                    style={{ fontSize: "14px", fontFamily: "Poppins, sans-serif" }}
                  >
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Support Section */}
          <div>
            <h4
              className="mb-4"
              style={{ fontSize: "16px", fontFamily: "Poppins, sans-serif" }}
            >
              Support
            </h4>
            <ul className="space-y-2">
              {supportLinks.map((link) => (
                <li key={link}>
                  <a
                    href="#"
                    className="text-white/90 hover:text-white transition-colors"
                    style={{ fontSize: "14px", fontFamily: "Poppins, sans-serif" }}
                  >
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </footer>
  );
}
