import { useState } from "react";
import { Menu, X } from "lucide-react";

export function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { name: "Home", active: true },
    { name: "Workouts", active: false },
    { name: "Progress", active: false },
    { name: "Programs", active: false },
    { name: "Profile", active: false },
  ];

  return (
    <header className="absolute top-0 left-0 right-0 text-white z-50">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <div className="flex-shrink-0">
            <h1 className="text-lg md:text-[22px]">Fit Tracker Pro</h1>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-6 xl:space-x-12">
            {navItems.map((item) => (
              <a
                key={item.name}
                href="#"
                className={`px-4 py-1 rounded-[5px] transition-colors ${
                  item.active
                    ? "bg-[#ff4b00] text-white"
                    : "text-white hover:text-[#ff4b00]"
                }`}
                style={{ fontSize: "14px", fontFamily: "Poppins, sans-serif", fontWeight: "400" }}
              >
                {item.name}
              </a>
            ))}
          </nav>

          {/* Desktop Action Buttons */}
          <div className="hidden lg:flex items-center space-x-3">
            <button
              className="bg-white text-black px-5 py-1.5 rounded-[5px] hover:bg-gray-100 transition-colors"
              style={{ fontSize: "12px", fontFamily: "Inter, sans-serif" }}
            >
              Sign out
            </button>
            <button
              className="bg-[#ff4b00] text-white px-5 py-1.5 rounded-[5px] hover:bg-[#e64400] transition-colors"
              style={{ fontSize: "12px", fontFamily: "Inter, sans-serif" }}
            >
              Get Started
            </button>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="lg:hidden p-2"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <div className="lg:hidden py-4 border-t border-white/10">
            <nav className="flex flex-col space-y-2">
              {navItems.map((item) => (
                <a
                  key={item.name}
                  href="#"
                  className={`px-4 py-2 rounded-[5px] transition-colors ${
                    item.active
                      ? "bg-[#ff4b00] text-white"
                      : "text-white hover:text-[#ff4b00]"
                  }`}
                  style={{ fontSize: "14px", fontFamily: "Poppins, sans-serif", fontWeight: "400" }}
                >
                  {item.name}
                </a>
              ))}
            </nav>
            <div className="flex flex-col space-y-2 mt-4">
              <button
                className="bg-white text-black px-5 py-2 rounded-[5px] hover:bg-gray-100 transition-colors"
                style={{ fontSize: "12px", fontFamily: "Inter, sans-serif" }}
              >
                Sign out
              </button>
              <button
                className="bg-[#ff4b00] text-white px-5 py-2 rounded-[5px] hover:bg-[#e64400] transition-colors"
                style={{ fontSize: "12px", fontFamily: "Inter, sans-serif" }}
              >
                Get Started
              </button>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
