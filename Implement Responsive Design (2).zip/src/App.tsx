import svgPaths from "./imports/svg-mzetapwmn7";
import imgRectangle63 from "figma:asset/c491f7ef1beb68ea6e73df17ada25c6315ba9454.png";
import imgRectangle64 from "figma:asset/6912bb928260a9a2f9eea85aa5a791b80ff346e2.png";
import imgRectangle65 from "figma:asset/5f3315d5eb1fdfc434a31d07c328551bfd2ec1d3.png";
import imgRectangle66 from "figma:asset/8c84b4c9255e4692e1dd49ab2f5fc6aa20d5d333.png";
import imgRectangle67 from "figma:asset/ef7ec98f045d830a785e34acd7369f96413f6157.png";
import imgRectangle68 from "figma:asset/777f77f18afebb5f87c58ddbd6bd5c388200f42b.png";
import imgRectangle69 from "figma:asset/2709371a8e2a03b62ec16b4d12478fc95c6123c2.png";
import imgRectangle70 from "figma:asset/d1be1db393a5a959fa63a6b220a4b118d3f6826c.png";
import imgHappyYoungAsianLadyDoingPlankFatBurningWorkoutFitnessClass1 from "figma:asset/bb16abbf657cded8631fcda51737363135bb4122.png";
import imgImage20 from "figma:asset/9cf0754ef2f6a4cdac821f94130fad3ab689e87b.png";
import { Header } from "./components/Header";
import { WorkoutCard } from "./components/WorkoutCard";
import { ExerciseList } from "./components/ExerciseList";
import { Timer } from "./components/Timer";
import { Footer } from "./components/Footer";

export default function App() {
  const exercises = [
    {
      image: imgRectangle63,
      name: "Plank (hold 30–60 sec)",
    },
    {
      image: imgRectangle64,
      name: "Bicycle Crunches (15–20 reps per side)",
    },
    {
      image: imgRectangle70,
      name: "Mountain Climbers (30–45 sec | 3 reps)",
    },
    {
      image: imgRectangle65,
      name: "Russian Twists (20 reps)",
    },
    {
      image: imgRectangle66,
      name: "Leg Raises (12–15 reps)",
    },
    {
      image: imgRectangle67,
      name: "Flutter Kicks (30–40 sec)",
    },
    {
      image: imgRectangle68,
      name: "Side Plank (20–30 sec each side | 2 reps)",
    },
    {
      image: imgRectangle69,
      name: "Sit-ups or Crunches (15–20 reps)",
    },
  ];

  return (
    <div className="min-h-screen bg-[#fcf5f3]">
      <Header />
      
      {/* Hero Section */}
      <div className="relative h-[400px] md:h-[500px] w-full overflow-hidden">
        <img
          src={imgHappyYoungAsianLadyDoingPlankFatBurningWorkoutFitnessClass1}
          alt="Workout Activity"
          className="absolute inset-0 w-full h-full object-cover"
          style={{ objectPosition: 'center center' }}
        />
        <div className="absolute inset-0 bg-black/30" />
        <div className="relative h-full max-w-7xl mx-auto px-4 md:px-8 flex flex-col justify-center pt-16 md:pt-20">
          <h1 className="text-white text-3xl md:text-[44px] mb-4 md:mb-6">
            Workout Activity
          </h1>
          <p className="text-white text-base md:text-[20px] max-w-[570px]">
            Track your fitness journey and celebrate your achievements.
          </p>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 md:px-8 py-6 md:py-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8">
          {/* Workout Card */}
          <div className="lg:col-span-3">
            <WorkoutCard image={imgImage20} />
          </div>

          {/* Exercise List */}
          <div className="lg:col-span-6">
            <ExerciseList exercises={exercises} />
          </div>

          {/* Timer */}
          <div className="lg:col-span-3">
            <Timer svgPaths={svgPaths} />
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
