import svgPaths from "./svg-mzetapwmn7";
import imgRectangle63 from "figma:asset/c491f7ef1beb68ea6e73df17ada25c6315ba9454.png";
import imgRectangle64 from "figma:asset/6912bb928260a9a2f9eea85aa5a791b80ff346e2.png";
import imgRectangle65 from "figma:asset/5f3315d5eb1fdfc434a31d07c328551bfd2ec1d3.png";
import imgRectangle66 from "figma:asset/8c84b4c9255e4692e1dd49ab2f5fc6aa20d5d333.png";
import imgRectangle67 from "figma:asset/ef7ec98f045d830a785e34acd7369f96413f6157.png";
import imgRectangle68 from "figma:asset/777f77f18afebb5f87c58ddbd6bd5c388200f42b.png";
import imgRectangle69 from "figma:asset/2709371a8e2a03b62ec16b4d12478fc95c6123c2.png";
import imgRectangle70 from "figma:asset/d1be1db393a5a959fa63a6b220a4b118d3f6826c.png";
import imgHappyYoungAsianLadyDoingPlankFatBurningWorkoutFitnessClass1 from "figma:asset/bb16abbf657cded8631fcda51737363135bb4122.png";
import imgImage20 from "figma:asset/9cf0754ef2f6a4cdac821f94130fad3ab689e87b.png";

function Group() {
  return (
    <div className="absolute contents left-[146px] top-[33px]">
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[normal] left-[calc(50%-814px)] not-italic text-[22px] text-white top-[54px] w-[219.607px]">Fit Tracker Pro</p>
      <div className="absolute bg-white h-[23px] left-[calc(50%+526.5px)] rounded-[5px] top-[35px] translate-x-[-50%] w-[77px]" />
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[normal] left-[calc(50%+500.89px)] not-italic text-[12px] text-[rgba(0,0,0,0.92)] top-[38px] w-[56.673px]">Sign out</p>
      <div className="absolute bg-[#ff4b00] h-[23px] left-[1588px] rounded-[5px] top-[35px] w-[97px]" />
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[normal] left-[calc(50%+640.91px)] not-italic text-[12px] text-white top-[38px] w-[96.344px]">Get Started</p>
      <div className="absolute bg-[#ff4b00] bottom-[94.81%] left-[calc(50%+161px)] rounded-[5px] top-[3.56%] translate-x-[-50%] w-[88px]" />
      <p className="absolute bottom-[95.67%] font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[normal] left-[calc(50%-465px)] not-italic text-[15px] text-white top-[3.27%] w-[45px]">Home</p>
      <p className="absolute bottom-[95.48%] font-['Poppins:SemiBold',sans-serif] leading-[normal] left-[calc(50%-277px)] not-italic text-[15px] text-white top-[3.17%] w-[74px]">Workouts</p>
      <p className="absolute bottom-[95.48%] font-['Poppins:SemiBold',sans-serif] leading-[normal] left-[calc(50%+327px)] not-italic text-[15px] text-white top-[3.17%] w-[50px]">Profile</p>
      <p className="absolute bottom-[95.44%] font-['Poppins:SemiBold',sans-serif] leading-[normal] left-[calc(50%+123px)] not-italic text-[15px] text-white top-[3.18%] w-[77px]">Programs</p>
      <p className="absolute bottom-[95.48%] font-['Poppins:SemiBold',sans-serif] leading-[normal] left-[calc(50%-74px)] not-italic text-[15px] text-white top-[3.17%] w-[69px]">Progress</p>
    </div>
  );
}

function Group2() {
  return (
    <div className="absolute contents left-[62px] top-[755px]">
      <div className="absolute bg-gradient-to-r from-[#ff4b00] h-[52px] left-[62px] rounded-[10px] to-[#ff7c45] top-[755px] w-[304px]" />
      <p className="absolute font-['Poppins:Bold',sans-serif] h-[24px] leading-[normal] left-[150.58px] not-italic text-[20px] text-white top-[766px] w-[171.683px]">Start Workout</p>
    </div>
  );
}

function Group3() {
  return (
    <div className="absolute contents left-[62px] top-[853px]">
      <div className="absolute bg-gradient-to-r from-[#ff4b00] h-[52px] left-[62px] rounded-[10px] to-[#ff7c45] top-[853px] w-[304px]" />
      <p className="absolute font-['Poppins:Bold',sans-serif] h-[24px] leading-[normal] left-[152px] not-italic text-[20px] text-white top-[862px] w-[137px]">End Workout</p>
    </div>
  );
}

function Group1() {
  return (
    <div className="absolute contents left-[62px] top-[755px]">
      <Group2 />
      <Group3 />
    </div>
  );
}

function Exercise() {
  return (
    <div className="absolute contents left-[476px] top-[446px]" data-name="exercise">
      <p className="absolute font-['Poppins:Regular',sans-serif] leading-[24px] left-[567px] not-italic text-[15px] text-black text-nowrap top-[464px] whitespace-pre">Plank (hold 30–60 sec)</p>
      <div className="absolute left-[476px] size-[60px] top-[446px]">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute h-[90%] left-[1.67%] max-w-none top-[6.67%] w-[98.33%]" src={imgRectangle63} />
        </div>
      </div>
    </div>
  );
}

function Exercise1() {
  return (
    <div className="absolute contents left-[476px] top-[522px]" data-name="exercise">
      <p className="absolute font-['Poppins:Regular',sans-serif] leading-[24px] left-[567px] not-italic text-[15px] text-black text-nowrap top-[540px] whitespace-pre">Bicycle Crunches (15–20 reps per side)</p>
      <div className="absolute left-[476px] size-[60px] top-[522px]">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute h-[97.5%] left-[-16.67%] max-w-none top-0 w-[134.59%]" src={imgRectangle64} />
        </div>
      </div>
    </div>
  );
}

function Exercise2() {
  return (
    <div className="absolute contents left-[475px] top-[669px]" data-name="exercise">
      <p className="absolute font-['Poppins:Regular',sans-serif] leading-[24px] left-[566px] not-italic text-[15px] text-black text-nowrap top-[687px] whitespace-pre">Russian Twists (20 reps)</p>
      <div className="absolute left-[475px] size-[60px] top-[669px]">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute h-full left-[-8.45%] max-w-none top-[-1.67%] w-[138.57%]" src={imgRectangle65} />
        </div>
      </div>
    </div>
  );
}

function Exercise3() {
  return (
    <div className="absolute contents left-[475px] top-[741px]" data-name="exercise">
      <p className="absolute font-['Poppins:Regular',sans-serif] leading-[24px] left-[566px] not-italic text-[15px] text-black text-nowrap top-[759px] whitespace-pre">Leg Raises (12–15 reps)</p>
      <div className="absolute left-[475px] size-[60px] top-[741px]">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgRectangle66} />
      </div>
    </div>
  );
}

function Exercise4() {
  return (
    <div className="absolute contents left-[475px] top-[817px]" data-name="exercise">
      <p className="absolute font-['Poppins:Regular',sans-serif] leading-[24px] left-[566px] not-italic text-[15px] text-black text-nowrap top-[835px] whitespace-pre">Flutter Kicks (30–40 sec)</p>
      <div className="absolute left-[475px] size-[60px] top-[817px]">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute h-[94.17%] left-[1.67%] max-w-none top-[5%] w-[98.12%]" src={imgRectangle67} />
        </div>
      </div>
    </div>
  );
}

function Exercise5() {
  return (
    <div className="absolute contents left-[475px] top-[893px]" data-name="exercise">
      <p className="absolute font-['Poppins:Regular',sans-serif] leading-[24px] left-[566px] not-italic text-[15px] text-black text-nowrap top-[911px] whitespace-pre">Side Plank (20–30 sec each side | 2 reps)</p>
      <div className="absolute left-[475px] size-[60px] top-[893px]">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute h-[98.33%] left-[1.67%] max-w-none top-[1.67%] w-[95%]" src={imgRectangle68} />
        </div>
      </div>
    </div>
  );
}

function Exercise6() {
  return (
    <div className="absolute contents left-[475px] top-[969px]" data-name="exercise">
      <p className="absolute font-['Poppins:Regular',sans-serif] leading-[24px] left-[566px] not-italic text-[15px] text-black text-nowrap top-[987px] whitespace-pre">Sit-ups or Crunches (15–20 reps)</p>
      <div className="absolute left-[475px] size-[60px] top-[969px]">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute left-0 max-w-none size-full top-0" src={imgRectangle69} />
        </div>
      </div>
    </div>
  );
}

function Exercise7() {
  return (
    <div className="absolute contents left-[475px] top-[596px]" data-name="exercise">
      <p className="absolute font-['Poppins:Regular',sans-serif] leading-[24px] left-[566px] not-italic text-[15px] text-black text-nowrap top-[614px] whitespace-pre">Mountain Climbers (30–45 sec | 3 reps)</p>
      <div className="absolute bg-[#d9d9d9] left-[475px] size-[60px] top-[596px]" />
      <div className="absolute left-[475px] size-[60px] top-[596px]">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute left-0 max-w-none size-full top-0" src={imgRectangle70} />
        </div>
      </div>
    </div>
  );
}

function Component() {
  return (
    <div className="absolute h-[24px] left-[1566px] top-[666px] w-[59px]" data-name="Component 1">
      <p className="absolute left-0 top-0">0</p>
      <p className="absolute left-[28px] top-0">0</p>
    </div>
  );
}

function Timer() {
  return (
    <div className="absolute contents font-['Poppins:Regular',sans-serif] leading-[24px] left-[1495px] not-italic text-[48px] text-black text-nowrap top-[663px] whitespace-pre" data-name="timer">
      <Component />
      <p className="absolute left-[1495px] top-[666px]">00</p>
      <p className="absolute left-[1556px] top-[663px]">:</p>
    </div>
  );
}

function Vector() {
  return (
    <div className="absolute h-[84px] left-[1535px] top-[903px] w-[75px]" data-name="Vector">
      <div className="absolute bottom-0 left-[-4%] right-[-4%] top-0">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 81 84">
          <g id="Vector">
            <path d={svgPaths.p36059680} fill="var(--fill-0, black)" id="Vector_2" />
          </g>
        </svg>
      </div>
    </div>
  );
}

export default function Sessions() {
  return (
    <div className="bg-[#fcf5f3] relative size-full" data-name="Sessions">
      <div className="absolute h-[416px] left-0 top-[-1px] w-[1922px]" data-name="happy-young-asian-lady-doing-plank-fat-burning-workout-fitness-class 1">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute h-[307.96%] left-0 max-w-none top-[-111.94%] w-full" src={imgHappyYoungAsianLadyDoingPlankFatBurningWorkoutFitnessClass1} />
        </div>
      </div>
      <p className="absolute font-['Poppins:Bold',sans-serif] leading-[normal] left-[114px] not-italic text-[44px] text-nowrap text-white top-[174px] whitespace-pre">Workout Activity</p>
      <div className="absolute font-['Poppins:SemiBold',sans-serif] leading-[normal] left-[114px] not-italic text-[20px] text-white top-[240px] w-[570px]">
        <p className="mb-0">Track your fitness journey and celebrate your achievements.</p>
        <p>&nbsp;</p>
      </div>
      <p className="absolute font-['Poppins:Medium',sans-serif] leading-[normal] left-[1124px] not-italic text-[16px] text-nowrap text-white top-[1438px] whitespace-pre">Support</p>
      <p className="absolute font-['Poppins:Regular',sans-serif] leading-[normal] left-[1124px] not-italic text-[14px] text-nowrap text-white top-[1479px] whitespace-pre">{`Help Center `}</p>
      <p className="absolute font-['Poppins:Regular',sans-serif] leading-[normal] left-[1124px] not-italic text-[14px] text-nowrap text-white top-[1509px] whitespace-pre">Privacy Policy</p>
      <p className="absolute font-['Poppins:Regular',sans-serif] leading-[normal] left-[1124px] not-italic text-[14px] text-nowrap text-white top-[1540px] whitespace-pre">Term of Service</p>
      <Group />
      <div className="absolute h-[254px] left-[25px] rounded-[18px] top-[442px] w-[390px]" data-name="image 20">
        <div className="absolute inset-0 overflow-hidden pointer-events-none rounded-[18px]">
          <img alt="" className="absolute h-[126.46%] left-0 max-w-none top-[-0.01%] w-full" src={imgImage20} />
        </div>
      </div>
      <Group1 />
      <div className="absolute bg-[#ff8654] h-[599px] left-[458px] rounded-[10px] top-[436px] w-[584px]" />
      <div className="absolute h-0 left-[458px] top-[516px] w-[584px]">
        <div className="absolute bottom-0 left-0 right-0 top-[-2px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 584 2">
            <line id="Line 4" stroke="var(--stroke-0, white)" strokeWidth="2" x2="584" y1="1" y2="1" />
          </svg>
        </div>
      </div>
      <div className="absolute h-0 left-[458px] top-[590px] w-[584px]">
        <div className="absolute bottom-0 left-0 right-0 top-[-2px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 584 2">
            <line id="Line 4" stroke="var(--stroke-0, white)" strokeWidth="2" x2="584" y1="1" y2="1" />
          </svg>
        </div>
      </div>
      <div className="absolute h-0 left-[458px] top-[664px] w-[584px]">
        <div className="absolute bottom-0 left-0 right-0 top-[-2px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 584 2">
            <line id="Line 4" stroke="var(--stroke-0, white)" strokeWidth="2" x2="584" y1="1" y2="1" />
          </svg>
        </div>
      </div>
      <div className="absolute h-0 left-[458px] top-[738px] w-[584px]">
        <div className="absolute bottom-0 left-0 right-0 top-[-2px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 584 2">
            <line id="Line 4" stroke="var(--stroke-0, white)" strokeWidth="2" x2="584" y1="1" y2="1" />
          </svg>
        </div>
      </div>
      <div className="absolute h-0 left-[458px] top-[812px] w-[584px]">
        <div className="absolute bottom-0 left-0 right-0 top-[-2px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 584 2">
            <line id="Line 4" stroke="var(--stroke-0, white)" strokeWidth="2" x2="584" y1="1" y2="1" />
          </svg>
        </div>
      </div>
      <div className="absolute h-0 left-[458px] top-[886px] w-[584px]">
        <div className="absolute bottom-0 left-0 right-0 top-[-2px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 584 2">
            <line id="Line 4" stroke="var(--stroke-0, white)" strokeWidth="2" x2="584" y1="1" y2="1" />
          </svg>
        </div>
      </div>
      <div className="absolute h-0 left-[458px] top-[960px] w-[584px]">
        <div className="absolute bottom-0 left-0 right-0 top-[-2px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 584 2">
            <line id="Line 4" stroke="var(--stroke-0, white)" strokeWidth="2" x2="584" y1="1" y2="1" />
          </svg>
        </div>
      </div>
      <Exercise />
      <Exercise1 />
      <Exercise2 />
      <Exercise3 />
      <Exercise4 />
      <Exercise5 />
      <Exercise6 />
      <Exercise7 />
      <div className="absolute h-[402px] left-[1356px] top-[476px] w-[407px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 407 402">
          <path d={svgPaths.p1bbeb700} id="Ellipse 13" stroke="url(#paint0_linear_5_149)" strokeWidth="5" />
          <defs>
            <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_5_149" x1="203.5" x2="203.5" y1="0" y2="402">
              <stop offset="0.235577" stopColor="#FF4B00" />
              <stop offset="0.610577" stopColor="#ED8B62" />
            </linearGradient>
          </defs>
        </svg>
      </div>
      <Timer />
      <Vector />
    </div>
  );
}